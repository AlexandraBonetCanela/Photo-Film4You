package edu.uoc.epcsd.user.infrastructure.repository.jpa;

public interface DomainTranslatable<T> {

    T toDomain();

}
